
# IT Hardware Asset Tracking & Lifecycle Dashboard

## Project Overview
This project simulates an enterprise IT Asset Management environment focused on hardware lifecycle operations, inventory tracking, reporting automation, and device refresh workflows.

The project demonstrates practical experience with:
- IT hardware inventory management
- Device lifecycle tracking
- Operational reporting
- Data cleaning and validation
- Power BI dashboard concepts
- Excel and SQL-based reporting workflows
- Endpoint inventory automation

## Key Features
- Asset inventory dataset with lifecycle statuses
- Refresh and warranty tracking
- Device allocation monitoring
- Simulated lifecycle workflows
- Reporting automation scripts
- PowerShell endpoint inventory collection examples

## Tools & Technologies
- Power BI
- Excel
- SQL
- Python
- PowerShell

## Sample Dashboard Ideas
- Active vs Retired Devices
- Devices Pending Refresh
- Inventory by Location
- Hardware Distribution by Department
- Warranty Expiry Tracking
- Device Lifecycle Status Breakdown

## Files Included
- asset_inventory_dataset.csv
- asset_inventory_schema.sql
- inventory_reporting.py
- endpoint_inventory_script.ps1

## Resume Alignment
This project supports experience in:
- IT Asset Management
- Hardware Lifecycle Operations
- Operational Reporting
- Endpoint Inventory Tracking
- Power BI Reporting
- Data Validation and Standardization
- ITSM Workflow Concepts
