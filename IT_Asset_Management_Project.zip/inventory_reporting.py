
import pandas as pd

df = pd.read_csv('asset_inventory_dataset.csv')

active_assets = df[df['Status'] == 'Active']

print('Total Assets:', len(df))
print('Active Assets:', len(active_assets))

refresh_due = df[df['Status'] == 'Pending Refresh']
print('Devices Pending Refresh:', len(refresh_due))
