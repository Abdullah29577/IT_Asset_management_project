
CREATE TABLE asset_inventory (
    Asset_ID VARCHAR(20) PRIMARY KEY,
    Device_Model VARCHAR(100),
    Assigned_Department VARCHAR(50),
    Status VARCHAR(50),
    Location VARCHAR(100),
    Purchase_Date DATE,
    Refresh_Date DATE,
    Warranty_Expiry DATE,
    Estimated_Value_CAD INT
);
