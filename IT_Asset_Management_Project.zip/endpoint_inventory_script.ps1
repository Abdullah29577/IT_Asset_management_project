
Get-ComputerInfo | Select-Object CsName, WindowsVersion, OsArchitecture

Get-BitLockerVolume | Select-Object MountPoint, ProtectionStatus

Get-WmiObject Win32_ComputerSystem | Select-Object Manufacturer, Model
